import java.net.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Arrays;
import java.util.Scanner;

class Client 
{
	private Socket sockfd;
	private DataOutputStream enSortie;
	private DataInputStream enEntree;
	
	public Client(String hote)
	{
		//Déclaration des variables
		int portno = 5001;
		byte[] buffer;
		String a = "ok";
		byte[] ok;
		
		try {
			sockfd = new Socket(hote, portno);
			enSortie = new DataOutputStream(sockfd.getOutputStream()); /*données a destination du correspondant*/ 
			enEntree = new DataInputStream(sockfd.getInputStream()); /*données venant du correspondant*/			
			Scanner clavier = new Scanner(System.in);
			System.out.printf("Please enter the message:");
			String str = clavier.nextLine(); //On récupère ce que le client a entré
			buffer = str.getBytes();
			enSortie.write(buffer,0,buffer.length); //On écrit dans le buffer
			ok = a.getBytes();
     		while(true){ //Boucle infinie dans lequel on va afficher le fichier
     	
				buffer = new byte[256];
				int n = enEntree.read(buffer,0,buffer.length);
				if (n<1){
					break;
				}
				System.out.println("n="+ n); //taille de la ligne
				String message = new String(buffer,0,n);
				System.out.println(message);
				enSortie.write(ok,0,ok.length); //acquittement 
		}
			//Fermeture des sockets 
     		 enSortie.close();
             enEntree.close();
             sockfd.close();
		}
			catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		new Client(args[0]);
	}
}