/*simpleClientSocket.c*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<netdb.h>

int main(int argc,char*argv[])
{
    //Déclaration des variables
    int sockfd,portno;
    char buffer[256];
    char ligne[256];
    char reponse[256]; 
    struct sockaddr_in serv_addr;
    struct hostent *server;

    if(argc < 3){
       fprintf(stderr,"usage %s hostname port\n", argv[0]);
       exit(0);
    }

    portno = atoi(argv[2]);

    /* Create a socket point */
    sockfd = socket(PF_INET,SOCK_STREAM,0);

    server = gethostbyname(argv[1]);

    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, //identique à memcpy
                        (char*)&serv_addr.sin_addr.s_addr,server->h_length);

    serv_addr.sin_port = htons(portno);

    //Connection au serveur
    connect(sockfd,(struct sockaddr *)&serv_addr,sizeof(serv_addr));

    /*Demander au client d'entrer le fichier souhaité.
    Ce message sera lu et traité par le serveur*/
    printf("Entrez le nom de fichier du groupe dont vous souhaitez faire l'appel: ");
    bzero(buffer,256);
    fgets(buffer,255,stdin);
    write(sockfd,buffer,strlen(buffer));
    
    //Tant qu'on peut lire les lignes, lire la réponse du serveur
    while(read(sockfd,ligne,256)){
    
       printf("%s",ligne);
       bzero(ligne,256);
       printf("Cet élève est-il présent (o ou n)? \n");//Vérifie la présence de l'élève
       fgets(reponse,255,stdin); //stocke la réponse dans serveur 
       write(sockfd, reponse, strlen(reponse)); //envoi au serveur 
       bzero(reponse,256); //On complète le buffer réponse avec des 0
       
       }

    return 0;
}
