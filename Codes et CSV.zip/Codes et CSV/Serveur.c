/* multipleServerSocket.c */ 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
 
void doprocessing (int sock) 
{   
    //Déclaration des variables 
    char buffer[256]; 
    char ligne[256];
    FILE* fichier;
    FILE* presence;
    
    bzero(buffer,256); //Compléter le buffer avec des 0
    read(sock,buffer,256); 
    buffer[strcspn(buffer, "\n")]='\0'; //Remplace les sauts de lignes par le caractère nul dans le buffer
    fichier = fopen(buffer,"r"); //Ouvrir le fichier en lecture seule
    printf("Fichier demandé par le client: %s\n",buffer); 

    //Si le fichier entré n'existe pas
    if (fichier == NULL){
	printf("Fichier non trouvé\n");
    }
   
    //Création d'un nouveau fichier dans lequel on va écrire qui est absent ou présent	   
    presence = fopen("presence.txt", "w");
    
    //Tant qu'on parvient à lire une ligne dans le fichier.
    while (fgets(ligne, 256, fichier)){
    	
        bzero(buffer,256);
        write(sock,ligne,strlen(ligne)); //envoi de la ligne au client 
        printf("%s",ligne);
        read(sock,buffer,256); //lit la réponse
        
	//Si le client a noté l'élève absent 
	if (strchr(buffer, 'n')){
		strcat(ligne, "absent\n"); //concaténation
		fputs(ligne, presence); //On écrit la chaîne dans le fichier
	}
	//Si le client a noté l'élève présent
	else if (strchr(buffer, 'o')){
		strcat(ligne, "présent\n");
		fputs(ligne, presence);
	}
    }

    //Fermeture du socket et des fichiers
    fclose(fichier);
    fclose(presence);
    close(sock);
} 

int main( int argc, char *argv[] ) 
{ 
    int sockfd, newsockfd, portno; 
    unsigned int clilen; 
 
    struct sockaddr_in serv_addr, cli_addr; 
    pid_t pid; 
     
    /* Premier appel de la fonction socket() */ 
    sockfd = socket(PF_INET, SOCK_STREAM, 0); 
     
    /* Initialisation socket structure */ 
    bzero((char *) &serv_addr, sizeof(serv_addr)); 
    portno = 5001; 
     
    serv_addr.sin_family = AF_INET; 
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY); 
    serv_addr.sin_port = htons(portno); 
     
    /* Now bind the host address using bind() call.*/ 
    bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)); 
     
    /* Now start listening for the clients, here 
     * process will go in sleep mode and will wait 
     * for the incoming connection */ 
    listen(sockfd,5); 
    clilen = sizeof(cli_addr); 
     
    while (1) 
    { 
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr,  
                           &clilen); 
        /* Create child process */ 
        pid = fork(); 
         
        if (pid == 0) 
        { 
            /* This is the client process */ 
            close(sockfd); 
            doprocessing(newsockfd); 
            exit(0); 
        } 

        else 
        { 
            close(newsockfd); 
        } 
    } /* fin de boucle */ 
}
