package com.example.saeprog;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import android.content.Context;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
    private Button monBouton;
    private EditText monText;
    private TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        monText = findViewById(R.id.editTextTextPersonName2);
        monBouton = findViewById(R.id.ButtonID1);



        monBouton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                String valeur = monText.getText().toString();
                System.out.println(valeur);

                String hostname = "192.168.0.162";
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        new Client(hostname, valeur);
                    }
                }).start();
            }
        });
    }
}

// Class to represent the client
class Client {
    private Socket sockfd;
    private DataOutputStream enSortie;
    private DataInputStream enEntree;

    public Client(String hote, String valeur) {
        int portno = 5001;
        byte[] buffer;
        String a = "ok";
        byte[] ok;


        try {
            sockfd = new Socket(hote, portno);
            enSortie = new DataOutputStream(sockfd.getOutputStream());
            enEntree = new DataInputStream(sockfd.getInputStream());
            String str = valeur;
            buffer = str.getBytes();
            enSortie.write(buffer,0,buffer.length);
            ok = a.getBytes();
            while(true){

                buffer = new byte[256];
                int n = enEntree.read(buffer,0,buffer.length);
                if (n<1){
                    break;
                }
                String message = new String(buffer,0,n);
                System.out.println(message);
                enSortie.write(ok,0,ok.length);

            }
            enSortie.close();
            enEntree.close();
            sockfd.close();
        } catch (IOException e) {
            e.printStackTrace();
        }


        }

}